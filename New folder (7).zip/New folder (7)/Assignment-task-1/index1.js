// Q=1

// let score = 48;
// if (score >= 90) {
//     console.log("greade A");

// } else if (score >= 80 && score < 89) {
//     console.log("greade B");

// } else if (score >= 70 && score <= 79) {
//     console.log("greade c");

// } else if (score < 70 && score >= 50) {
//     console.log("greade d");

// } else {
//     console.log("fail");

// }





//Q=2

//  let a=5;
//  let b=5;
//  let c=7;
//  if(a === b && b === c && a === c){
//      console.log("Equilateral triangle.");

//  }else if(a === b || b === c || a===c){
//      console.log("Isosceles triangle.");

//  }else{
//      console.log("Scalene triangle");
//     
//  }





// Q=3

// let num=30;
// if(num % 2===0){
//     if(num>50){
//         console.log("Even and Large");

//     }else{
//         console.log("Even and small");

//     }
// }else{
//     if(num<30){
//         console.log("Odd and small");


//     }else{
//         console.log("Odd and Large");

//     }
// }



// Q=1

// let a=5;
// for(let i=1; i<=10; i++){
//     console.log(i*a);

// }




// Q=2

// let num=6;

// let tamp=0;
// for(let i=1; i<=num; i++){
//     tamp+=i;
// }
// console.log(tamp);



//Q=3


// const rows = 4;
// let a = '';
// for (let i = 1; i <= rows; i++) {
//   for (let j = 1; j <= i; j++) {
//     a += j + ' ';
//   }
//   a += '\n';
// }
// console.log(a);



// for loop Q


//Q=1

// for(let i=1; i<=5; i++){
//     star=""
//     for(let j=1; j<=i; j++){
//         star+="*"
//     }
//     console.log(star);

// }



//Q=2

// for(let i=1; i<=5; i++){
//     star=""
//     for(let j=5; j>=i; j--){
//         star+="*"
//     }
//     console.log(star);

// }



//Q=3


// let a=5;

// for (let i = 1; i <= a; i++) {
//     let pattern = "   ";
//     for (let j = 1; j <= a - i; j++) {
//         pattern += " ";
//     }
//     for (let k = 1; k <= 2 * i - 1; k++) {
//         pattern += "*";
//     }
//     console.log(pattern);
// }


//Q=4


// for(let i=1; i<=5; i++){
//     str=" "
//     for(let j=1; j<=i; j++){
//         str=str+=j+" "
//     }
//     console.log(str);
    
// }




//Q=5

// for(let i=1; i<=5; i++){
//     str=" "
//     for(let j=5; j>=i; j--){
//         str=str+=j+" "
//     }
//     console.log(str);
    
// }







//Q=6

    //  let n=9;

    // for (let i = 1; i <= n; i += 2) {
    //     console.log(" ".repeat((n - i) / 2) + "*".repeat(i));
    // }


    // for (let i = n - 2; i >= 1; i -= 2) {
    //     console.log(" ".repeat((n - i) / 2) + "*".repeat(i));
    // }










































